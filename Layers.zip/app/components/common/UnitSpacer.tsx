import React from 'react'

const UnitSpacer: React.FC = () => (
  <div className="mt-40" />
)

export default UnitSpacer
